package com.spring.test;

import org.apache.commons.configuration.beanutils.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(SpringConfiguration.class);
		EmployeeBean empBean=context.getBean(EmployeeBean.class);
		empBean.setName("Sanjay");
		empBean.setName("Sanjay1");
		System.out.println(empBean.getName());
		CurrencyBean currBean=context.getBean(CurrencyBean.class);
		CurrencyBean currBean1=context.getBean(CurrencyBean.class);
		currBean=new CurrencyBean(100, "INR");
		currBean1=new CurrencyBean(100, "USD");
		System.out.println(currBean.getSymbol());
		//currBean.setSymbol("USD");
		System.out.println(currBean1.getSymbol());
		https://www.boraji.com/spring-lazy-annotation-example
			http://www.developersbook.com/spring/interview-questions/spring-interview-questions-faqs.php
			
		
	}

}
