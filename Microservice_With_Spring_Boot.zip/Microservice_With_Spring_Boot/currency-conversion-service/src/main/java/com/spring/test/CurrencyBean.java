package com.spring.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.annotation.Scope;

@Scope(value=ConfigurableListableBeanFactory.SCOPE_SINGLETON)
public class CurrencyBean {
	private int code;
	private String symbol;
	
	@Autowired
	public CurrencyBean(int code, String symbol) {
		super();
		this.code = code;
		this.symbol = symbol;
	}
	public CurrencyBean() {
		super();
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

}
