package com.spring.test;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfiguration {
	@Bean
	public EmployeeBean empBean()
	{
		return new EmployeeBean();
	}
	
	@Bean
	public StudentBean stuBean()
	{
		return new StudentBean();
	}
	@Bean
	public CurrencyBean currBean()
	{
		return new CurrencyBean(100,"INR");
	}

}
