package com.wipro.microservices;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

//@FeignClient(name="currency-exchange-service")//Connecting to currency-exchange service directly
@FeignClient(name="netflix-zuul-api-gateway-server")//Connecting through Zuul API gateway

/*
 * if you notice here url of currency-exchange-service is hard coded
 * means it can talk to only one instance of it. But when load is more how it will be balanced?
 * Here comes Ribbon Load Balancing concept which we will be configuring in next demo
 name- Name of microservice which will be invoked--this name you will find application.properties file of that application
 *url-url of the microservice
  */
@RibbonClient(name="currency-exchange-service")//urls configured in properties file
public interface CurrencyConversionServiceProxy {
	
	//@GetMapping("/currency-exchange/from/{from}/to/{to}")
	@GetMapping("/currency-exchange-service/currency-exchange/from/{from}/to/{to}")//currency-exchange-service is appended to
	//talk with zuul
	public CurrencyConversionBean retrieveExchangeValue(@PathVariable ("from")String from, @PathVariable ("to")String to);
	/*
	 * if we use  CurrencyConversionBean retrieveExchangeValue(@PathVariable String from, @PathVariable String to);
	 * java.lang.IllegalStateException: Either 'name' or 'value' must be provided in @FeignClient is thrown
	 * */
}
