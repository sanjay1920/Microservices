package com.wipro.microservices;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

/*All the methods will be executed for all the incoming requests*/
@Component
public class ZuulLogginFilter extends ZuulFilter {
	private Logger logger=LoggerFactory.getLogger(this.getClass());

	@Override
	public Object run() throws ZuulException {
		
		HttpServletRequest httpRequest = RequestContext.getCurrentContext().getRequest();//getting current request from zuul
		logger.info("request -> {}, request uri -> {}",httpRequest,httpRequest.getRequestURI());
		return null;
	}

	@Override
	public boolean shouldFilter() {
		/*This method is for should this filter be executed or not
		 * we can insert some business logic over here to decide
		 * */
		return true;
	}

	@Override
	public int filterOrder() {
		/*Filter order we can set based upon requirement
		 * like 1 for Logging
		 * 2 for Security and so on
		 * */
		return 1;
	}

	@Override
	public String filterType() {
		/*When filtering should happing - There are three filter types
		 *  pre - before the request is executed
		 *  post - after the request has executed
		 *  error - if we want to filter only error request/exception
		 * */
		return "pre";
	}

}
