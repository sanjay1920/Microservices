package com.wipro.microservices;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
/*I forgot to define this Anotation, Thrown null pointer exception while invoking it 
 * in controller class
 * */
public interface ExchangeValueRepository  extends JpaRepository<ExchangeValue, Long>{

	ExchangeValue findByFromAndTo(String from, String to);
	

}
